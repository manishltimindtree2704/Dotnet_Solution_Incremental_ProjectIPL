export interface Team {
    id?: any;
    name: string;
    maximumBudget: number;
  }
  