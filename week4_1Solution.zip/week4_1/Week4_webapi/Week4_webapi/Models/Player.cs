﻿namespace Week4_webapi.Models
{
    public class Player
    {
        public long Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string Category { get; set; }
        public double BiddingPrice { get; set; }
    }
}
