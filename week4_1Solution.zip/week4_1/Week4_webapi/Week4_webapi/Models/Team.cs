﻿namespace Week4_webapi.Models
{
    public class Team
    {
        public long Id { get; set; }
        public string Name { get; set; }
        public double MaximumBudget { get; set; }
    }

}
