﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Week4_webapi.Models;

namespace Week4_webapi.Controllers
{
    [Route("api/users")]
    [ApiController]
    [EnableCors("AllowAny")]

    public class UserController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public UserController(ApplicationDbContext context)
        {
            _context = context;
        }

        // POST: api/users/register
        [HttpPost("register")]
        public async Task<ActionResult<User>> Register(User user)
        {
            // Implement user registration logic here
            // Validate user input, hash password, etc.
            // Add the user to the database

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(Login), new { id = user.Id }, user);
        }

        // POST: api/users/login
        // POST: api/users/login
        [HttpPost("login")]
        public async Task<ActionResult<object>> Login(User user)
        {
            // Find the user by username
            var existingUser = await _context.Users.FirstOrDefaultAsync(u => u.Username == user.Username);
            Console.WriteLine(existingUser.Role);

            // Check if the user exists and if the provided password matches
            if (existingUser != null && existingUser.Password == user.Password && existingUser.Role == user.Role)
            {
                // You can use authentication mechanisms here if needed.
                // For simplicity, we assume a successful login.

                // Return a response with a message and the user object
                return new
                {
                    Message = "Login successful",
                    User = existingUser
                };
            }

            // If login fails, return an error response
            return BadRequest("Login failed");
        }




    }
}